/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vending_machine_micheal_luong;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author micheal
 */
public class Vending_Machine_Micheal_Luong {

    /**
     * @param args the command line arguments
     */
     
    public static boolean useJframe = false;
    public static Vending_Machine vm = new Vending_Machine();
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Sound.Init(4);
        Sound sound = new Sound();
        sound.Start();
        vm.Init();
        System.out.println("Do you want to use the (1) Jframe or the (2) console as a display screen.");
        Scanner scans = new Scanner(System.in);
        int answer;
        answer = scans.nextInt();
        if (answer == 1) {
            new Option_JMenu();
        } else {
            System.out.println("There's a candy vending machine right here.");
            System.out.println("You grab your wallet out and examine the options available.");
            boolean loop = true;
            while (loop) {
                vm.printOptions();
                System.out.println("To buy a candy, type in the location of the candy.");
                System.out.println("To read the guide book type 4");
                System.out.println("To Quit type quit.");
                Scanner scan = new Scanner(System.in);
                String[] response = scan.nextLine().split(",");
                if (response[0].equalsIgnoreCase("4")) {
                    System.out.println("Here are the rules:");
                    Rules();
                } else if (response[0].equalsIgnoreCase("quit")) {
                    loop = false;
                    Sound.Init(3);
                    sound.Start();
                    System.out.println("The machine powers down...");
                    System.out.println("Press Enter...");
                    scan.nextLine();
                    sound.Stop();
                    System.exit(0);
                } else {
                    try {
                        Sound.Init(1);
                        sound.Start();
                        vm.Select(response);
                    } catch (ArrayIndexOutOfBoundsException e) {
                        System.out.println("I did not understand you...");
                    } 
                }
            }
        }
        
    }

    static void Rules() {
        System.out.println("This is a Vending Machine full of candies.");
        System.out.println("To select a Candy, you must type in the coordinates");
        System.out.println("of the candy with the rows being either a letter or number");
        System.out.println("and the column being a number.");
        System.out.println("Make sure it is in the form of row, column before proceeding.");
        System.out.println("\n\n\n\n\n\n");
    }
}
