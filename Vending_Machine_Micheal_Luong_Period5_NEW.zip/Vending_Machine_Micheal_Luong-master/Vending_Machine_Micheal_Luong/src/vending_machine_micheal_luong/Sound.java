/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vending_machine_micheal_luong;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

/**
 *
 * @author micheal
 */
public class Sound {

    public static AudioStream as;

    public static void Init(int type) throws FileNotFoundException, IOException {
        if (type == 1) {
            InputStream in = new FileInputStream(new File("music/select.wav"));
            AudioStream select = new AudioStream(in);
            Sound.as = select;
        } else if (type == 2) {
            InputStream in = new FileInputStream(new File("music/drop.wav"));
            AudioStream drop = new AudioStream(in);
            Sound.as = drop;
        } else if (type == 3) {
            InputStream in = new FileInputStream(new File("music/off.wav"));
            AudioStream off = new AudioStream(in);
            Sound.as = off;
        } else if (type == 4) {
            InputStream in = new FileInputStream(new File("music/on.wav"));
            AudioStream on = new AudioStream(in);
            Sound.as = on;
        }
    }

    public void Start() {
        AudioPlayer.player.start(as);
    }

    public void Stop() {
        AudioPlayer.player.stop(as);
    }
}
