/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vending_machine_micheal_luong;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author micheal
 */
public class Option_JMenu {
    private JFrame window;
    private JFrame window2;

    private JPanel panel;
    private JPanel panel2;

    private JButton b1;
    private JButton b2;
    private JButton b3;
    private JButton b4;
    private JButton b5;
    private JButton b6;
    private JButton b7;
    private JButton b8;
    private JButton b9;

    public static JTextArea text;

    public Option_JMenu() {
        GUI();
    }
    
    public void GUI() {
        Vending_Machine_Micheal_Luong.useJframe = true;        
        text = new JTextArea(7, 10);
        text.setFont(new Font("Sans Serif", Font.PLAIN, 15));
        window = new JFrame("Micheal's Vending Machine");
        window.setVisible(true);
        window.setSize(600, 400);

        window2 = new JFrame("Micheal's Vending Machine");
        window2.setVisible(true);
        window2.setSize(300, 200);

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(new GridLayout(3, 4, 5, 10));
        panel.setBackground(Color.black);
        panel2 = new JPanel(new GridBagLayout());
        panel2.setBackground(Color.YELLOW);

        GridBagConstraints c = new GridBagConstraints();
        b1 = new JButton("KitKats");
        b1.setBackground(Color.red);
        Dimension d1 = new Dimension(110, 80);
        b1.setPreferredSize(d1);
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String[] input = {"a", "1"};
                try {
                    Vending_Machine_Micheal_Luong.vm.Select(input);
                } catch (IOException ex) {
                    Logger.getLogger(Option_JMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
                IntroStatement();
            }
        });

        b2 = new JButton("Snickers");
        b2.setBackground(Color.lightGray);
        Dimension d2 = new Dimension(110, 80);
        b2.setPreferredSize(d2);
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent f) {
                String[] input = {"a", "2"};
                try {
                    Vending_Machine_Micheal_Luong.vm.Select(input);
                } catch (IOException ex) {
                    Logger.getLogger(Option_JMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
                IntroStatement();
                //JOptionPane.showMessageDialog(null, "Action2\nhello");
            }
        });

        b3 = new JButton("m&m's");
        b3.setBackground(Color.GREEN);
        Dimension d3 = new Dimension(110, 80);
        b3.setPreferredSize(d3);
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String[] input = {"a", "3"};
                try {
                    Vending_Machine_Micheal_Luong.vm.Select(input);
                } catch (IOException ex) {
                    Logger.getLogger(Option_JMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
                IntroStatement();
            }
        });

        b4 = new JButton("Herseys");
        b4.setBackground(Color.CYAN);
        Dimension d4 = new Dimension(110, 80);
        b4.setPreferredSize(d4);
        b4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String[] input = {"b", "1"};
                try {
                    Vending_Machine_Micheal_Luong.vm.Select(input);
                } catch (IOException ex) {
                    Logger.getLogger(Option_JMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
                IntroStatement();
            }
        });

        b5 = new JButton("Skittles");
        b5.setBackground(Color.MAGENTA);
        Dimension d5 = new Dimension(110, 80);
        b5.setPreferredSize(d5);
        b5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String[] input = {"b", "2"};
                try {
                    Vending_Machine_Micheal_Luong.vm.Select(input);
                } catch (IOException ex) {
                    Logger.getLogger(Option_JMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
                IntroStatement();
            }
        });

        b6 = new JButton("Twixes");
        b6.setBackground(Color.PINK);
        Dimension d6 = new Dimension(110, 80);
        b6.setPreferredSize(d6);
        b6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String[] input = {"b", "3"};
                try {
                    Vending_Machine_Micheal_Luong.vm.Select(input);
                } catch (IOException ex) {
                    Logger.getLogger(Option_JMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
                IntroStatement();
            }
        });

        b7 = new JButton("GummiWorms");
        b7.setBackground(Color.lightGray);
        Dimension d7 = new Dimension(110, 80);
        b7.setPreferredSize(d7);
        b7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String[] input = {"c", "1"};
                try {
                    Vending_Machine_Micheal_Luong.vm.Select(input);
                } catch (IOException ex) {
                    Logger.getLogger(Option_JMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
                IntroStatement();
            }
        });

        b8 = new JButton("ButterFingers");
        b8.setBackground(Color.YELLOW);
        Dimension d8 = new Dimension(110, 80);
        b8.setPreferredSize(d8);
        b8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String[] input = {"c", "2"};
                try {
                    Vending_Machine_Micheal_Luong.vm.Select(input);
                } catch (IOException ex) {
                    Logger.getLogger(Option_JMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
                IntroStatement();
            }
        });

        b9 = new JButton("Starburts");
        b9.setBackground(Color.CYAN);
        Dimension d9 = new Dimension(110, 80);
        b9.setPreferredSize(d9);
        b9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String[] input = {"c", "3"};
                try {
                    Vending_Machine_Micheal_Luong.vm.Select(input);
                } catch (IOException ex) {
                    Logger.getLogger(Option_JMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
                IntroStatement();
            }
        });

        c.insets = new Insets(1, 1, 11, 11);
        c.gridx = 0;
        c.gridy = 1;

        panel.add(b1);
        c.gridx = 3;
        c.gridy = -1;
        panel2.add(text);

        c.gridx = 0;
        c.gridy = 2;
        panel.add(b2);
        panel.add(b3);
        panel.add(b4);
        panel.add(b5);
        panel.add(b6);
        panel.add(b7);
        panel.add(b8);
        panel.add(b9);
        window.add(panel);
        window2.add(panel2);
    }
    
    void IntroStatement() {
        System.out.println("There's a candy vending machine right here.");
        System.out.println("You grab your wallet out and examine the options available.");
        System.out.println("To buy a candy push the panel forward.");
        System.out.println("To Quit close this window.");
        System.out.println("\n\n\n\n\n");
    }
}
